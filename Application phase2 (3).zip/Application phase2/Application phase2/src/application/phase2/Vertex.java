
package application.phase2;



public class Vertex {

    boolean isVisted = false; //retrn true or false if visit all vertex 
    int weight; 

    public Vertex() {
      
    }

    public Vertex(int weight) {  // set weight tol the verex
        this.weight = weight;
    }

}
